from django.shortcuts import render
from .models import Product
from django.shortcuts import render, get_object_or_404
from django.shortcuts import redirect
from .forms import ProductFilterForm 

def product_list(request):
    products = Product.objects.all()
    return render(request, 'product_list.html', {'products': products})

def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, 'product_detail.html', {'product': product})

def contact(request):
    return render(request, 'contact.html')

def add_to_cart(request, pk):
    product = get_object_or_404(Product, pk=pk)
    
    cart = request.session.get('cart', {})

    product_id = str(product.id)
    if product_id in cart:
        cart[product_id]['quantity'] += 1
    else:
        cart[product_id] = {
            'name': product.name,
            'price': float(product.price),
            'quantity': 1,
        }
    
    request.session['cart'] = cart 

    return redirect('products:product_list') 

def cart(request):
    cart = request.session.get('cart', {})
    return render(request, 'cart.html', {'cart': cart})


def product_filter(request):
    products = Product.objects.all()  

    form = ProductFilterForm(request.GET)
    if form.is_valid():
        min_price = form.cleaned_data.get('min_price')
        max_price = form.cleaned_data.get('max_price')

        if min_price:
            products = products.filter(price__gte=min_price)
        if max_price:
            products = products.filter(price__lte=max_price)

    return render(request, 'product_filter.html', {'products': products, 'form': form})
