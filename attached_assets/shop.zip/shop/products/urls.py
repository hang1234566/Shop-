from django.urls import path
from . import views

app_name = 'products'  

urlpatterns = [
    path('', views.product_list, name='product_list'),
    path('contact/', views.contact, name='contact'), 
    path('<int:pk>/', views.product_detail, name='product_detail'),
    path('add-to-cart/<int:pk>/', views.add_to_cart, name='add_to_cart'),
    path('cart/', views.cart, name='view_cart'),
    path('product-filter', views.product_filter, name='product_filter'),

    
]


