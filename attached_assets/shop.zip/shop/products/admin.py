from django.contrib import admin
from .models import Product
from django.utils.translation import gettext_lazy as _

admin.site.register(Product)

admin.site.site_header = _("Quản trị cửa hàng")
admin.site.site_title = _("Trang quản trị")
admin.site.index_title = _("Trang quản trị chính")

