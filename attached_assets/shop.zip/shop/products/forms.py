from django import forms

class ProductFilterForm(forms.Form):
    min_price = forms.DecimalField(max_digits=10, decimal_places=2, required=False, label="Giá tối thiểu")
    max_price = forms.DecimalField(max_digits=10, decimal_places=2, required=False, label="Giá tối đa")

